package presentacion;

import datos.RepresentanteDAO;
import datos.ClienteDAO;
import javax.servlet.ServletException;
import javax.swing.JOptionPane;
import negocio.Controlador;
import util.RHException;

public class Cliente {

    public static void main(String[] args) throws ServletException {
        Controlador c = new Controlador();
        ClienteDAO cl= new ClienteDAO();

        
      //  try {
    
        
       
        
      //  System.out.println(c.autenticarCliente(0,0));
            //c.incluirCliente(0, nombre, apellido, telefono, 0, 0);
            //c.cambiarContrasenaRep(1234567, 102517);
         // c.incluirCliente(1012, "MILTON", "Orozco", "84512451", 1323, 102517);
         //c.registrarCliente("MILTONSSS",147);
          //c.autenticarRepresentante("laDoris",123456);
          //c.incluirCliente(94225, "Luis", "Ramirez", "782", 2255, 102517);
           //;

        //} catch (RHException f) {
          //  JOptionPane.showMessageDialog(null, f, "Error", JOptionPane.ERROR_MESSAGE);

        //}
        
        
        //c.buscarRepresentante(102517);
        
        

    }

}
